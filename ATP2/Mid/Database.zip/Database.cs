using System.Collections.Generic;

public class Employee
{
    public int EmployeeId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public double Salary { get; set; }
    public int DepartmentId { get; set; }

}

public class Department
{
    public int DepartmentId { get; set; }
    public string Name { get; set; }
    public string Location { get; set; }
}

public class Database
{
    private List<Employee> employees;
    private List<Department> departments;

    public Database()
    {
        this.employees = new List<Employee>();
        this.departments = new List<Department>();
    }

    public List<Employee> Employees
    {
        get { return this.employees; }
        set { this.employees = value; }
    }

    public List<Department> Departments
    {
        get { return this.departments; }
        set { this.departments = value; }
    }
}

/*
 * Add the following function in your Global.asax file

protected void Session_Start()
{
    Session["DATABASE"] = new Database();
}

*/